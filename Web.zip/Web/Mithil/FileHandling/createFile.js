var fs = require('fs');

txt = "This is demo text";

fs.writeFile('demo.txt', txt, function(err){
    if(err){throw err;}
    console.log("File created successfully.....");
})