const Calculator = require('./calculator');

const resultAdd = Calculator.add(5, 3);
console.log(`Addition: ${resultAdd}`);

const resultSubtract = Calculator.subtract(8, 3);
console.log(`Subtraction: ${resultSubtract}`);

const resultMultiply = Calculator.multiply(4, 6);
console.log(`Multiplication: ${resultMultiply}`);

const resultDivide = Calculator.divide(10, 2);
console.log(`Division: ${resultDivide}`);
