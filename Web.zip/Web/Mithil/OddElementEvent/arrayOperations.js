// arrayOperations.js

const EventEmitter = require('events');

class ArrayOperations extends EventEmitter {
  constructor() {
    super();
  }

  findSumOfOddElements(arr) {
    const sumOdd = arr.reduce((acc, num) => (num % 2 !== 0 ? acc + num : acc), 0);
    this.emit('sumOdd', sumOdd);
  }

  findSumOfEvenElements(arr) {
    const sumEven = arr.reduce((acc, num) => (num % 2 === 0 ? acc + num : acc), 0);
    this.emit('sumEven', sumEven);
  }
}

// Export an instance of ArrayOperations
module.exports = new ArrayOperations();
