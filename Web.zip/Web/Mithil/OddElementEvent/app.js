// app.js

const arrayOperations = require('./arrayOperations');

// Example array
const myArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// Register listeners for 'sumOdd' and 'sumEven' events
arrayOperations.on('sumOdd', (sum) => {
  console.log(`Sum of odd elements: ${sum}`);
});

arrayOperations.on('sumEven', (sum) => {
  console.log(`Sum of even elements: ${sum}`);
});

// Trigger the functions
arrayOperations.findSumOfOddElements(myArray);
arrayOperations.findSumOfEvenElements(myArray);
