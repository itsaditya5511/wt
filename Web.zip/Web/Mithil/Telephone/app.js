// app.js

angular.module('telephoneBillApp', [])
  .controller('telephoneBillController', function ($scope) {

    $scope.calculateBill = function () {
      var numberOfCalls = $scope.numberOfCalls;
      var totalBill = 0;

      if (numberOfCalls <= 200) {
        totalBill = numberOfCalls * 0;
      } else if (numberOfCalls <= 500) {
        totalBill = (200 * 0) + ((numberOfCalls - 200) * 1);
      } else {
        totalBill = (200 * 0) + (300 * 1) + ((numberOfCalls - 500) * 2);
      }

      // Adding the rental charge
      totalBill += 200;

      $scope.totalBill = totalBill;
      $scope.billCalculated = true;
    };

  });
