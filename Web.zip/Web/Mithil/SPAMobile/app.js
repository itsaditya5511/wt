// app.js

angular.module('mobileStoreApp', ['ngRoute'])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/phones', {
        templateUrl: 'phones.html',
        controller: 'PhonesController'
      })
      .when('/accessories', {
        templateUrl: 'accessories.html',
        controller: 'AccessoriesController'
      })
      .otherwise({ redirectTo: '/phones' });
  })
  .controller('PhonesController', function ($scope) {
    $scope.products = [
      { name: 'iPhone 12', price: 999 },
      { name: 'Samsung Galaxy S21', price: 899 },
      { name: 'Google Pixel 5', price: 699 }
    ];
  })
  .controller('AccessoriesController', function ($scope) {
    $scope.accessories = [
      { name: 'Wireless Earbuds', price: 99 },
      { name: 'Phone Case', price: 19 },
      { name: 'Screen Protector', price: 9 }
    ];
  });
