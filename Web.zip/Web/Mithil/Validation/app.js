angular.module('registrationFormApp', [])
  .controller('registrationFormController', function ($scope) {
    $scope.formData = {};
    $scope.formSubmitted = false;

    $scope.submitForm = function () {
      $scope.formSubmitted = true;
    };
  });
