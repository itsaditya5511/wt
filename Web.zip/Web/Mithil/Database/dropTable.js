var mysql = require('mysql')

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'webpractical'
})

con.connect(function(err){
    if(err){throw err;}
    sql = 'DELETE TABLE student';
    con.query(sql, function(err){
        if(err){throw err;}
        console.log("Table deleted successfully");
    })
})