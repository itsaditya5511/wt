var mysql = require('mysql');

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'webpractical'
})

con.connect(function(err){
    if(err){throw err;}
    sql = 'CREATE TABLE student(rollNo int PRIMARY KEY, name varchar(20), marks int)';
    con.query(sql, function(err){
        if(err){throw err;}
        console.log("Table created successfully..........");
    })
})