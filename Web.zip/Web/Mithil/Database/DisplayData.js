var mysql = require('mysql')

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'webpractical'
})

con.connect(function(err){
    if(err){throw err;}
    sql1 = 'SELECT * FROM student';
    sql2 = 'SELECT * FROM student WHERE rollNo = 4';
    sql3 = 'SELECT * FROM student ORDER BY name';
    sql4 = 'SELECT * FROM student WHERE percentage > 90';
    con.query(sql3, function(err, result){
        if(err){throw err;}
        console.log(result);
    })
})