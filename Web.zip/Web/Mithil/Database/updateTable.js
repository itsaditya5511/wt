var mysql = require('mysql');

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'Webpractical'
})

con.connect(function(err){
    if(err){throw err;}
    console.log("Connected");

    sql = 'UPDATE student SET marks = 67 WHERE rollNo = 2';
    con.query(sql, function(err){
        if(err){throw err;}
        console.log("Data updated successfully")
    })
})