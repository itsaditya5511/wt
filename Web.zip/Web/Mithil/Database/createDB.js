var mysql = require("mysql");

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
});


// Creating database
con.connect(function(err){
    if(err){throw err;}
    sql = 'CREATE DATABASE webpractical';
    con.query(sql, function(err){
        if(err){throw  err;}
        console.log("Database created successfully......");
    })
})