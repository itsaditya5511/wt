var mysql = require('mysql')

var con = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'webpractical'
})

con.connect(function(err){
    if(err){throw err;}
    sql = "INSERT INTO student(rollNo, name, marks) VALUES ?;";
    let val = [
        [1, 'Mithil', 60],
        [2, 'bhavesh', 70],
        [3, 'pravat', 80],
        [4, 'omkar', 90]
    ];

    con.query(sql, [val], function(err){
        if(err){throw err;}
        console.log("Values Inserted Successfully.........");
    })
})