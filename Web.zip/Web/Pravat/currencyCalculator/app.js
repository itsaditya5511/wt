// app.js

const currencyConverter = require('./currencyConverter');

// Convert $100 to Rupees
const dollars = 100;
const rupees = currencyConverter.dollarsToRupees(dollars);
console.log(`${dollars} USD is equal to ${rupees.toFixed(2)} INR`);

// Convert 7421 Rupees to Dollars
const rupeesAmount = 7421;
const dollarsEquivalent = currencyConverter.rupeesToDollars(rupeesAmount);
console.log(`${rupeesAmount} INR is equal to ${dollarsEquivalent.toFixed(2)} USD`);
