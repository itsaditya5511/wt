// currencyConverter.js

const exchangeRate = 74.21; // 1 USD = 74.21 INR (Indian Rupees)

function dollarsToRupees(amountInDollars) {
    return amountInDollars * exchangeRate;
}

function rupeesToDollars(amountInRupees) {
    return amountInRupees / exchangeRate;
}

module.exports = {
    dollarsToRupees,
    rupeesToDollars
};
