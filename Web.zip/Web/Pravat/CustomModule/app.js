// app.js

// Importing the custom cylinder module
const cylinder = require('./cylinder');

// Example usage
const radius = 5;
const height = 10;

// Calculate surface area
const sa = cylinder.surfaceArea(radius, height);
console.log('Surface Area:', sa.toFixed(2));

// Calculate volume
const vol = cylinder.volume(radius, height);
console.log('Volume:', vol.toFixed(2));
