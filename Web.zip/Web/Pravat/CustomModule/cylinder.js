// cylinder.js

// Function to calculate the surface area of a cylinder
function surfaceArea(radius, height) {
    const baseArea = Math.PI * radius * radius;
    const lateralArea = 2 * Math.PI * radius * height;
    return 2 * baseArea + lateralArea;
  }
  
  // Function to calculate the volume of a cylinder
  function volume(radius, height) {
    return Math.PI * radius * radius * height;
  }
  
  // Exporting the functions to be used in other modules
  module.exports = {
    surfaceArea,
    volume
  };
  