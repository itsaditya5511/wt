class MobilePhoneBrands {
    constructor() {
      this.brands = [];
    }
  
    addItem(brand) {
      this.brands.push(brand);
    }
  }
  
  const scope = {
    mobilePhoneBrands: new MobilePhoneBrands()
  };
  
  // Function to add items to the list
  function addBrandToList(brand) {
    scope.mobilePhoneBrands.addItem(brand);
  }
  
  // Example usage:
  addBrandToList("Apple");
  addBrandToList("Samsung");
  addBrandToList("Google");
  // Prompt the user to enter more brands and call addBrandToList with each input
  
  // Access the list of mobile phone brands
  console.log(scope.mobilePhoneBrands.brands);
  