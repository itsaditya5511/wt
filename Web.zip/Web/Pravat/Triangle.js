const Triangle = {
    // Function to determine the type of triangle
    getType: function(side1, side2, side3) {
        if (side1 === side2 && side2 === side3) {
            return "Equilateral";
        } else if (side1 === side2 || side1 === side3 || side2 === side3) {
            return "Isosceles";
        } else {
            return "Scalene";
        }
    },

    // Function to calculate the area of a triangle using Heron's formula
    getArea: function(side1, side2, side3) {
        const s = (side1 + side2 + side3) / 2;
        const area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
        return area;
    }
};

// Example usage:
const side1 = 5;
const side2 = 6;
const side3 = 5;

console.log("Type of triangle:", Triangle.getType(side1, side2, side3));
console.log("Area of triangle:", Triangle.getArea(side1, side2, side3));
