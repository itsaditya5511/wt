const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
    // Extract the file extension from the request URL
    const extension = path.extname(req.url);

    // Set appropriate content type based on the file extension
    let contentType = '';
    switch (extension) {
        case '.html':
            contentType = 'text/html';
            break;
        case '.pdf':
            contentType = 'application/pdf';
            break;
        case '.csv':
            contentType = 'text/csv';
            break;
        default:
            contentType = 'text/plain';
    }

    // Read the file and serve it with the appropriate content type
    const filePath = path.join(__dirname, req.url);
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/html' });
            return res.end('404 Not Found');
        }

        res.writeHead(200, { 'Content-Type': contentType });
        res.write(data);
        return res.end();
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// see output
// HTML file: http://localhost:3000/example.html
// PDF file: http://localhost:3000/example.pdf
// CSV file: http://localhost:3000/example.csv