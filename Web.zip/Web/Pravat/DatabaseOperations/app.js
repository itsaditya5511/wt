const mysql = require('mysql');

// Create connection
const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'abc'
});

// Connect to MySQL
con.connect(function(err) {
    if (err) throw err;
    console.log('Connected to MySQL database!');

    // Create Event table if not exists
    let createTableQuery = `CREATE TABLE IF NOT EXISTS Event (
        EventId INT AUTO_INCREMENT PRIMARY KEY,
        EventName VARCHAR(255) NOT NULL,
        EventDate DATE,
        ParticipantName VARCHAR(255),
        College VARCHAR(255)
    );`;

    con.query(createTableQuery, function(err, result) {
        if (err) throw err;
        console.log('Event table created or already exists.');

        // Insert records
        let insertQuery = `INSERT INTO Event (EventName, EventDate, ParticipantName, College) VALUES ?`;
        let values = [
            ['Event 1', '2024-02-01', 'Participant 1', 'College A'],
            ['Event 2', '2024-02-02', 'Participant 2', 'College B'],
            // Add more records here
        ];

        con.query(insertQuery, [values], function(err, result) {
            if (err) throw err;
            console.log(`${result.affectedRows} record(s) inserted.`);

            // Update operation
            let updateQuery = `UPDATE Event SET ParticipantName = 'Updated Participant' WHERE EventName = 'Event 1'`;
            con.query(updateQuery, function(err, result) {
                if (err) throw err;
                console.log(`${result.affectedRows} record(s) updated.`);

                // Delete operation
                let deleteQuery = `DELETE FROM Event WHERE EventName = 'Event 2'`;
                con.query(deleteQuery, function(err, result) {
                    if (err) throw err;
                    console.log(`${result.affectedRows} record(s) deleted.`);

                    // Drop Event table
                    let dropTableQuery = `DROP TABLE Event`;
                    con.query(dropTableQuery, function(err, result) {
                        if (err) throw err;
                        console.log('Event table dropped.');
                        
                        // Close connection
                        con.end();
                    });
                });
            });
        });
    });
});
