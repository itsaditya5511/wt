// Event system
const eventListeners = {};

function registerEvent(eventName, listener) {
  if (!eventListeners[eventName]) {
    eventListeners[eventName] = [];
  }
  eventListeners[eventName].push(listener);
}

function triggerEvent(eventName, data) {
  const listeners = eventListeners[eventName];
  if (listeners) {
    listeners.forEach(listener => listener(data));
  }
}

// Sorting function
function sortStrings(strings) {
  return strings.slice().sort();
}

// Searching function
function searchString(strings, target) {
  return strings.indexOf(target);
}

// Example usage
const stringArray = ['apple', 'banana', 'orange', 'grape'];

// Registering events
registerEvent('sort', sortedStrings => {
  console.log('Sorted strings:', sortedStrings);
});

registerEvent('search', index => {
  if (index !== -1) {
    console.log(`String found at index ${index}`);
  } else {
    console.log('String not found');
  }
});

// Triggering events
triggerEvent('sort', sortStrings(stringArray));
triggerEvent('search', searchString(stringArray, 'orange'));
