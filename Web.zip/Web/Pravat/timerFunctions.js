// Importing required modules
const { setTimeout, setInterval, clearInterval } = require('timers');

// Function to be called after a delay
function delayedFunction() {
    console.log("Delayed function called after 2 seconds");
}

// Function to be called at regular intervals
function intervalFunction() {
    console.log("Interval function called every second");
}

// Demonstrate setTimeout function
setTimeout(delayedFunction, 2000);

// Demonstrate setInterval function
const intervalID = setInterval(intervalFunction, 1000);

// Clear the interval after 5 seconds
setTimeout(() => {
    clearInterval(intervalID);
    console.log("Interval cleared after 5 seconds");
}, 5000);
