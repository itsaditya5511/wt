const EventEmitter = require('events');

class StringArrayOperations extends EventEmitter {
    constructor() {
        super();
    }
    
    sortArray(arr) {
        arr.sort();
        this.emit('arraySorted', arr);
    }

    searchArray(arr, searchTerm) {
        const result = arr.includes(searchTerm);
        this.emit('searchResult', result);
    }
}

// Example usage
const stringArrayOps = new StringArrayOperations();

// Handling events
stringArrayOps.on('arraySorted', (sortedArray) => {
    console.log('Array sorted:', sortedArray);
});

stringArrayOps.on('searchResult', (result) => {
    console.log('Search result:', result);
});

// Sorting an array
const unsortedArray = ['banana', 'apple', 'orange', 'grape'];
stringArrayOps.sortArray(unsortedArray);

// Searching for a string
const searchString = 'apple';
stringArrayOps.searchArray(unsortedArray, searchString);
