const express=require('express');
var app=express();

app.get('/login',function(req,res){
    res.sendFile(__dirname + '/login.html');
});

app.get('/register',function(req,res){
    res.sendFile(__dirname + '/register.html');
});

app.get('/Home',function(req,res){
    res.sendFile(__dirname + '/Home.html');
});

app.get('/formSubmit',function(req,res){
    const rno = req.query.rno;
    const name = req.query.name;
    const address = req.query.address;
    const email = req.query.email;
    const mobile = req.query.mobile;
    res.send(`<h2>Student Info</h2>Roll Number: ${rno}<br> Name: ${name}<br> Address: ${address}<br>Email: ${email}<br> Mobile No: ${mobile}`);
});
app.listen(8085);
