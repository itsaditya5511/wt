const fs=require('fs');
txt="My name is Omkar.";
txt1=" Age is 21.";

//Creating a new file
fs.writeFile('File.txt',txt,function(error){
    if(error){throw error;}
    console.log("File.txt created")
})

//read the file
fs.readFile('File.txt','utf-8',function(error,data){
    if(error){throw error;}
    console.log(data);
})

//Appending the file
fs.appendFile('File.txt',txt1,function(error){
    if(error){throw error;}
    console.log("data appended to file")
}) 


//read the file
fs.readFile('File.txt','utf-8',function(error,data){
    if(error){throw error;}
    console.log(data);
})

//delete file
fs.unlink('file1.txt',function(err){
    if(error){throw error;}
    console.log("deleted");
})

//rename file
fs.rename('file1.txt','renamed.txt',function(err){
    if(error){throw error;}
    console.log("file renamed");
})





