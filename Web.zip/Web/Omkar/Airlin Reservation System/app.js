
 
		var app = angular.module('myApp', []); 
		var app = angular.module('myApp', ['ngRoute']); 
		app.config(function ($routeProvider) { 
			$routeProvider 
				.when('/', { 
					templateUrl: 'first.html', 
					controller: 'FirstController' 
				}) 

				.when('/second', { 
					templateUrl: 'second.html', 
					controller: 'SecondController' 
				}) 

				.when('/third', { 
					templateUrl: 'third.html', 
					controller: 'ThirdController' 
				}) 

				.otherwise({ redirectTo: '/' }); 
		}); 

		