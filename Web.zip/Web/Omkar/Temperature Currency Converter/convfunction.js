// temperatureConverter.js

// Function to convert Celsius to Fahrenheit
function celsiusToFahrenheit(celsius) {
    const fahrenheit = (celsius * 9/5) + 32;
    return fahrenheit;
  }
  
  // Function to convert Fahrenheit to Celsius
  function fahrenheitToCelsius(fahrenheit) {
    const celsius = (fahrenheit - 32) * 5/9;
    return celsius;
  }
  
  // Export the functions for external use
  module.exports = {
    celsiusToFahrenheit,
    fahrenheitToCelsius
  };
  