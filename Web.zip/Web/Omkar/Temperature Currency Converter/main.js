// main.js

// Import the temperatureConverter module
const temperatureConverter = require('./convfunction');

// Example usage
const celsiusTemperature = 25;
const fahrenheitTemperature = temperatureConverter.celsiusToFahrenheit(celsiusTemperature);
console.log(`${celsiusTemperature} Celsius is ${fahrenheitTemperature.toFixed(2)} Fahrenheit`);

const fahrenheitTemperature2 = 98.6;
const celsiusTemperature2 = temperatureConverter.fahrenheitToCelsius(fahrenheitTemperature2);
console.log(`${fahrenheitTemperature2} Fahrenheit is ${celsiusTemperature2.toFixed(2)} Celsius`);
